using System.Net;
using System.Text.Json;
using System.Text;

namespace Client
{
    public partial class Form1 : Form
    {
        const int N = 22;
        private Control[] arrControls = new Control[N];
        string stringGuid = "";
        Color commonColor;

        private Random myRand = new Random();

        public Form1()
        {
            InitializeComponent();

            Guid myGuid = Guid.NewGuid();
            stringGuid = myGuid.ToString();

            int currPosition = 2;
            commonColor = Color.FromArgb(myRand.Next(100, 256), 0, myRand.Next(100, 256));

            for (int i = 0; i < N; i++)
            {
                if(myRand.Next(2) == 0)
                    arrControls[i] = new Button();
                else
                    arrControls[i] = new Label();
                arrControls[i].Location = new Point(currPosition, 3);
                arrControls[i].Size = new Size(myRand.Next(40, 120), 80);
                arrControls[i].TabIndex = i;
                arrControls[i].BackColor = commonColor;
                arrControls[i].Name = "Cat";
                if (myRand.Next(2) == 0)
                    arrControls[i].Name = "Dog";
                if (arrControls[i].GetType().Name == "Button")
                    ((Button)arrControls[i]).Image = Image.FromFile("../../../" + arrControls[i].Name + ".jpg");
                else
                    ((Label)arrControls[i]).Image = Image.FromFile("../../../" + arrControls[i].Name + ".jpg");

              arrControls[i].Click += new EventHandler(allControls_Click);

              currPosition += arrControls[i].Size.Width + 2;
              this.Controls.Add(arrControls[i]);
            }
        }
        private void allControls_Click(object sender, EventArgs e)
        {
            string url = "http://localhost:12345/";
            WebRequest request = WebRequest.Create(url);
            request.Method = "POST";

            Control tempControl = (Control)sender;
            DogCat_ButtonLabel_Width_index_Guid tempRGB_index_Guid = new DogCat_ButtonLabel_Width_index_Guid();
            tempRGB_index_Guid.mGuid = stringGuid;
            tempRGB_index_Guid.Width = tempControl.Width;
            if(tempControl is Label)
            {
                tempRGB_index_Guid.ButtonLabel = "Label";
            }
            if (tempControl is Button)
            {
                tempRGB_index_Guid.ButtonLabel = "Button";
            }
            tempRGB_index_Guid.index = tempControl.TabIndex;
            if (tempControl.Name == "Dog")
            {
                tempRGB_index_Guid.DogCat = "Dog";

            }
            if (tempControl.Name == "Cat")
            {
                tempRGB_index_Guid.DogCat = "Cat";

            }
          


            JsonSerializerOptions options = new JsonSerializerOptions { IncludeFields = true };
            string jsonString = JsonSerializer.Serialize(tempRGB_index_Guid, options);

            byte[] byteArray = Encoding.UTF8.GetBytes(jsonString);

            request.ContentLength = byteArray.Length;
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(byteArray, 0, byteArray.Length);

            WebResponse response = request.GetResponse();

            Stream responseStream = response.GetResponseStream();

            StreamReader reader = new StreamReader(responseStream);
            string resultStr = reader.ReadToEnd();
            if (resultStr == "Empty")
                return;

            /*int currPosition = 3;
            for (int i = 0; i < arrLabels.Length; i++)
            {
                arrLabels[i].Location = new Point(currPosition, 3);
                currPosition += arrLabels[i].Size.Width + 2;
            
           }*/
            int[]? resultArrIndexes = JsonSerializer.Deserialize<int[]>(resultStr, options);

            int newPosition = 3;
            for (int i = 0; i < resultArrIndexes!.Length; i++)
            {
                arrControls[resultArrIndexes[i]].Location = new Point(newPosition, 90);
                newPosition += arrControls[resultArrIndexes[i]].Width + 2;
            }


        }
    }
}