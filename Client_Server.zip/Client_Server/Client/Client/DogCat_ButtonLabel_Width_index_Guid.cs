﻿namespace Client
{
    public class DogCat_ButtonLabel_Width_index_Guid
    {
        public string DogCat = "";
        public string ButtonLabel = "";
        public int Width;
        public int index;
        public string mGuid = "";
    }
}