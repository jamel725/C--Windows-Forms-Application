﻿using System.Net;
using System.Text;
using System.Text.Json;

namespace Server
{
    class Program
    {
        static List<Guid_List_Width_index> commonList = new List<Guid_List_Width_index>();
        static string serverDogCat = "Dog";
        static string serverButtonLabel = "Button";
        static Random myRand = new Random();
        static void Main(string[] args)
        {
            if (myRand.Next(2) == 0)
                serverDogCat = "Cat";
            if (myRand.Next(2) == 0)
                serverButtonLabel = "Label";

            Console.WriteLine("Server Dog/Cat  = " + serverDogCat + "      Server Button/Label =  " + serverButtonLabel);

            HttpListener listener = new HttpListener();
            listener.Prefixes.Add("http://localhost:12345/");

            listener.Start();

		    Console.WriteLine("Server:  Listens on port 12345...");

            while (true)
            {
                HttpListenerContext context = listener.GetContext();
                HttpListenerRequest request = context.Request;

                int[] result_arrIndexes = null!;
                string resultString = "Empty";

                Stream body = request.InputStream;
                Encoding encoding = request.ContentEncoding;
                StreamReader reader = new StreamReader(body, encoding);

                string jsonString = reader.ReadToEnd();
                // Console.WriteLine(jsonString);
                reader.Close();
                body.Close();

                if (body != null)
                    result_arrIndexes = POST_function(jsonString);

                if (result_arrIndexes != null)
                {
                    JsonSerializerOptions options = new JsonSerializerOptions { IncludeFields = true };

                    resultString = JsonSerializer.Serialize(result_arrIndexes, options);
                    Console.WriteLine(resultString);
                }

                HttpListenerResponse response = context.Response;

                byte[] buffer = Encoding.UTF8.GetBytes(resultString);
                response.ContentLength64 = buffer.Length;

                Stream outputStream = response.OutputStream;
                outputStream.Write(buffer, 0, buffer.Length);
            }
        }

        private static int[] POST_function(string jsonString)
        {
            JsonSerializerOptions options = new JsonSerializerOptions { IncludeFields = true };

            DogCat_ButtonLabel_Width_index_Guid? myObect = JsonSerializer.Deserialize<DogCat_ButtonLabel_Width_index_Guid>(jsonString, options);
            if (myObect == null)
                return null!;

            if (serverDogCat != myObect.DogCat
                   ||
               serverButtonLabel != myObect.ButtonLabel
                  )
                return null!;
            Width_index tempwidth_index = new Width_index();
            tempwidth_index.Width = myObect.Width;
            tempwidth_index.index = myObect.index;
            int index = commonList.FindIndex(x => x.mGuid == myObect.mGuid);
            if (commonList.Count == 0 || index == -1)
            {
                Guid_List_Width_index tempGuid_List_width_index = new Guid_List_Width_index();
                tempGuid_List_width_index.mGuid = myObect.mGuid;
                tempGuid_List_width_index.mList_Width_index.Add(tempwidth_index);
                commonList.Add(tempGuid_List_width_index);
                if (index == -1)
                    index = commonList.FindIndex(a => a.mGuid == myObect.mGuid);
            }
            else
                commonList[index].mList_Width_index.Add(tempwidth_index);

            List<Width_index> myList = new List<Width_index>(commonList[index].mList_Width_index);
            myList.Sort((x, y) => x.Width-y.Width);

            int[] arrIndexes = myList.Select(x => x.index).ToArray(); ;

            return arrIndexes;


        }
    }
}


  
