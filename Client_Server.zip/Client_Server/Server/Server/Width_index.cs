﻿namespace Server
{
    public class Width_index
    {
        public int Width;
        public int index;
    }
}
