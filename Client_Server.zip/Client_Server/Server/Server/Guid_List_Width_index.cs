﻿namespace Server
{
    public class Guid_List_Width_index
    {
        public string mGuid = "";
        public List<Width_index> mList_Width_index = new List<Width_index>();
    }
}

