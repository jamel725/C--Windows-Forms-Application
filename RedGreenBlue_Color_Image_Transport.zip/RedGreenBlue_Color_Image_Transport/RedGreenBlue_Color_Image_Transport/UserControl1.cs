﻿namespace RedGreenBlue_Color_Image_Transport
{
    public partial class UserControl1 : UserControl
    {
        static Random myRand = new Random();
        public Label[] arrLabels;
        public UserControl1(int counter, int counterFull)
        {
            InitializeComponent();
            arrLabels = new Label[counter];
            this.Width = counter * 38 + 4;
            
            for (int i = 0; i < counter; i++)
            {
                arrLabels[i] = new Label();
                arrLabels[i].Size = new Size(36, 60);
                arrLabels[i].BackColor = Color.White;
                arrLabels[i].Location = new Point(2 + 38 * i, 3);
                this.Controls.Add(arrLabels[i]);
            }
            for (int i = 0; i < counterFull; i++)
            {
                switch (myRand.Next(3))
                {
                    case 0:  arrLabels[i].Name = "Red"; break;
                    case 1:  arrLabels[i].Name = "Green"; break;
                    case 2: arrLabels[i].Name = "Blue"; break;
                }
                if (myRand.Next(2) == 0)
                    arrLabels[i].BackColor = Color.FromName(arrLabels[i].Name); 
                else
                {
                    arrLabels[i].BackColor = Color.Black;
                    arrLabels[i].Image = Image.FromFile("../../../" + arrLabels[i].Name + ".jpg");
                }
            }
        }
    }
}
