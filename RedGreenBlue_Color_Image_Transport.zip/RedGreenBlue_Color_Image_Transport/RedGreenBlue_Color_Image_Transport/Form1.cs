﻿namespace RedGreenBlue_Color_Image_Transport
{
    public partial class Form1 : Form
    {
        private const int N = 48, N_Full = 26, N_Trasport = 5;

        private UserControl1[] arrUC_Storage = new UserControl1[3], arrUC_Transport = new UserControl1[3];
        private Color[] arrColors = new Color[] { Color.Red, Color.Green, Color.Blue};
 
        public Form1()
        {
            InitializeComponent();

            for (int i = 0; i < 3; i++)
            {
                arrUC_Storage[i] = new UserControl1(N, N_Full);
                arrUC_Storage[i].Location = new Point(3, 84 +110 * i);
                this.Controls.Add(arrUC_Storage[i]);

                arrUC_Transport[i] = new UserControl1(5, 0);
                arrUC_Transport[i].Location = new Point(10 + 420 * i, 436);
                this.Controls.Add(arrUC_Transport[i]);
            }
        }

        private void startToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
    }
}
