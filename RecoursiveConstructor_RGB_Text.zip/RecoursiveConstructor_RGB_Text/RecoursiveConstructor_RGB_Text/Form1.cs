﻿namespace RecoursiveConstructor_RGB_Text
{
    public partial class Form1 : Form
    {
        private UserControl1[] arrUC;
        private int arrUser_size = 2;
        static private Form1 Button_Form, Label_Form;
        private static Random formRand = new Random();
        public static UserControl1 Label_UC, Button_UC;
        private static List<Button> btn = new List<Button>();
        private static List<Label> lbl = new List<Label>();
        public static int count = 0;
        public static String first;
        // --------------------------------------


        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        public Form1(int counter)
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Normal;

            arrUC = new UserControl1[arrUser_size];
            for (int i = 0; i < arrUser_size; i++)
            {
                arrUC[i] = new UserControl1(formRand);
                arrUC[i].Location = new Point(120, 50 + 130 * i);
                arrUC[i].event_FromUC += new delegate_MyEventHadler(Form_event_FromUC);
                this.Controls.Add(arrUC[i]);
            }

            if (counter == 2)
            {
                Button_Form = this;
                this.Max_control = new Button();
                this.Max_control.Location = new Point(2, 2);
                this.Max_control.Size = new Size(20, 20);
                this.Max_control.BackColor = Color.White;
                this.Max_control.Font = new Font("Arial", 14, FontStyle.Bold);
                this.Controls.Add(this.Max_control);

                Form1 temp = new Form1(1);
                temp.Show();
            }

            if (counter == 1)
            {
                this.Text = "Label";
                Label_Form = this;
                this.Max_control = new Label();
                this.Max_control.Location = new Point(2, 2);
                this.Max_control.Size = new Size(20, 20);
                this.Max_control.BackColor = Color.White;
                ((Label)this.Max_control).TextAlign = ContentAlignment.MiddleCenter;
                this.Max_control.Font = new Font("Arial", 14, FontStyle.Bold);
                this.Controls.Add(this.Max_control);

                if (formRand.Next(2) == 0)
                    Button_Form.Green_Red_label.Text = "Red";
                else
                    Label_Form.Green_Red_label.Text = "Red";
    
                if (formRand.Next(2) == 0)
                    Button_Form.Rectangle_Square_label.Text = "Square";
                else
                    Label_Form.Rectangle_Square_label.Text = "Square";

                if (formRand.Next(2) == 0)
                {
                    Button_Form.bySize_byBrightness_label.Text = "byBrightness";
                    Button_Form.Text_Empty_label.Text = "Empty";
                }
                else
                {
                    Label_Form.bySize_byBrightness_label.Text = "byBrightness";
                    Label_Form.Text_Empty_label.Text = "Empty";
                }
            }
        }
        private void Form_event_FromUC(object sender, myEventArgs e)
        {
            if (count == 0)
            {
                if (this.Text == "Label")
                {
                    Label_UC = e.uc;
                    count++;
                    first = "Label";
                    return;
                }
                else
                {
                    Button_UC = e.uc;
                    count++;
                    first = "Button";
                    return;
                }
            }

            if (count == 1)
            {
                if (this.Text != first)
                {
                    if (first == "Label")
                    {
                        Button_UC = e.uc;
                        count++;


                    }
                    if (first == "Button")
                    {
                        Label_UC = e.uc;
                        count++;


                    }
                    Action();
                }
            }
        }

        private void Action()
        {
            for (int i = 0; i < Button_UC.arrControls.Length; i++)
            {
                if (Button_UC.arrControls[i] != null && Button_UC.arrControls[i] is Button)
                {
                    btn.Add((Button)Button_UC.arrControls[i]);
                }
            }
            for (int i = 0; i < Label_UC.arrControls.Length; i++)
            {
                if (Label_UC.arrControls[i] != null && Label_UC.arrControls[i] is Button)
                {
                    btn.Add((Button)Label_UC.arrControls[i]);
                }
            }
            for (int i = 0; i < Button_UC.arrControls.Length; i++)
            {
                if (Button_UC.arrControls[i] != null && Button_UC.arrControls[i] is Label)
                {
                    lbl.Add((Label)Button_UC.arrControls[i]);
                }
            }
            for (int i = 0; i < Label_UC.arrControls.Length; i++)
            {
                if (Label_UC.arrControls[i] != null && Label_UC.arrControls[i] is Label)
                {
                    lbl.Add((Label)Label_UC.arrControls[i]);
                }
            }
            lbl = filtergreenred(lbl, Label_Form.Green_Red_label.Text);
            btn = filtergreenred1(btn, Button_Form.Green_Red_label.Text);
            //////////////////////////////////////////////////////////////
            lbl = filterrecsquare(lbl, Label_Form.Rectangle_Square_label.Text);
            btn = filterrecsquare1(btn, Button_Form.Rectangle_Square_label.Text);
            ////////////////////////////////////////////////////////////////
            
            lbl = filtertext(lbl, Label_Form.bySize_byBrightness_label.Text);
            btn = filtertext1(btn, Button_Form.bySize_byBrightness_label.Text);
            if (lbl.First() == null)
            {
                Label_UC.Controls.Clear();
                return;
            }
            if (btn.First() == null)
            {
                Button_UC.Controls.Clear();
                 return;
            }
            if (Label_Form.bySize_byBrightness_label.Text == "bySize"&& Button_Form.Green_Red_label.Text=="Red")
            {
                lbl.Sort((x, y) => x.Width * x.Height - y.Width * y.Height);
                btn.Sort((x, y) => x.BackColor.R - y.BackColor.R);

            }
            if (Label_Form.bySize_byBrightness_label.Text == "bySize" && Button_Form.Green_Red_label.Text == "Green")
            {
                lbl.Sort((x, y) => x.Width * x.Height - y.Width * y.Height);
                btn.Sort((x, y) => x.BackColor.G - y.BackColor.G);

            }
            if (Button_Form.bySize_byBrightness_label.Text == "bySize"&& Label_Form.Green_Red_label.Text == "Red")
            {
                btn.Sort((x, y) => x.Width * x.Height - y.Width * y.Height);
                lbl.Sort((x, y) => x.BackColor.R - y.BackColor.R);
            }
            if (Button_Form.bySize_byBrightness_label.Text == "bySize" && Label_Form.Green_Red_label.Text == "Green")
            {
                btn.Sort((x, y) => x.Width * x.Height - y.Width * y.Height);
                lbl.Sort((x, y) => x.BackColor.G - y.BackColor.G);


            }
            Label_Form.Max_control.Size = lbl.Last().Size;
            Label_Form.Max_control.Name = lbl.Last().Name;
            Label_Form.Max_control.BackColor = lbl.Last().BackColor;
            Label_Form.Max_control.Font = lbl.Last().Font;
            Label_Form.Max_control.Text = lbl.Last().Text;
            Label_Form.Max_control.ForeColor = lbl.Last().ForeColor;
            ///////////////////////////////////////////
            Button_Form.Max_control.Size = btn.Last().Size;
            Button_Form.Max_control.Name = btn.Last().Name;
            Button_Form.Max_control.BackColor = btn.Last().BackColor;
            Button_Form.Max_control.Font = btn.Last().Font;
            Button_Form.Max_control.Text = btn.Last().Text;
            Button_Form.Max_control.ForeColor = btn.Last().ForeColor;
            Arrange(Label_UC,lbl);
            Arrange1(Button_UC, btn);
        }

        private List<Label> filtertext(List<Label> lbl, string bySize_byBrightness)
        {
            List<Label> result = new List<Label>();
            for (int i = 0; i < lbl.Count; i++)
            {
                if (lbl[i] != null)
                {
                    if (Label_Form.bySize_byBrightness_label.Text == "bySize" && lbl[i].Text != "")
                    {
                        result.Add(lbl[i]);
                    }
                    if (Label_Form.bySize_byBrightness_label.Text == "byBrightness" && lbl[i].Text == "")
                    {
                        result.Add(lbl[i]);
                    }
                }
            }
            return result;
        }

        private List<Button> filtertext1(List<Button> btn, string bySize_byBrightness)
        {
            List<Button> result = new List<Button>();
            for (int i = 0; i < btn.Count; i++)
            {
                if (btn[i] != null)
                {
                    if (Button_Form.bySize_byBrightness_label.Text == "bySize" && btn[i].Text != "")
                    {
                        result.Add(btn[i]);
                    }
                    if (Button_Form.bySize_byBrightness_label.Text == "byBrightness" && btn[i].Text == "")
                    {
                        result.Add(btn[i]);
                    }
                }
            }
            return result;
        }
        private List<Button> filterrecsquare1(List<Button> btn, string text)
        {
            List<Button> result = new List<Button>();
            for (int i = 0; i < btn.Count; i++)
            {
                if (btn[i] != null)
                {
                    if (text == "Square" && btn[i].Width == btn[i].Height)
                    {
                        result.Add(btn[i]);
                    }
                    if (text == "Rectangle" && btn[i].Width != btn[i].Height)
                    {
                        result.Add(btn[i]);
                    }

                }
            }
            return result;
        }

        private List<Label> filterrecsquare(List<Label> lbl, string text)
        {
            List<Label> result = new List<Label>();
            for (int i = 0; i < lbl.Count; i++)
            {
                if (lbl[i] != null)
                {
                    if (text == "Square" && lbl[i].Width == lbl[i].Height)
                    {
                        result.Add(lbl[i]);
                    }
                    if (text == "Rectangle" && lbl[i].Width != lbl[i].Height)
                    {
                        result.Add(lbl[i]);
                    }

                }
            }
            return result;
        }

        private List<Button> filtergreenred1(List<Button> btn, string green_Red_label)
        {
            List<Button> result = new List<Button>();
            for (int i = 0; i < btn.Count; i++)
            {
                if (btn[i] != null)
                {
                    if (btn[i].Text == "") {
                        if (green_Red_label == "Red" && btn[i].BackColor.R != 0)
                        {
                            result.Add(btn[i]);
                        }
                        if (green_Red_label == "Green" && btn[i].BackColor.G != 0)
                        {
                            result.Add(btn[i]);
                        }
                    }
                    if (btn[i].Text != "")
                    {
                        if (green_Red_label == "Red" && btn[i].Text=="R")
                        {
                            result.Add(btn[i]);
                        }
                        if (green_Red_label == "Green" && btn[i].Text=="G")
                        {
                            result.Add(btn[i]);
                        }
                    }

                }
            }
            return result;

        }

        private List<Label> filtergreenred(List<Label> lbl, string green_Red_label)
        {
            List<Label> result = new List<Label>();
            for (int i = 0; i < lbl.Count; i++)
            {
                if (lbl[i] != null)
                {
                    if (lbl[i].Text == "")
                    {
                        if (green_Red_label == "Red" && lbl[i].BackColor.R != 0 )
                        {
                            result.Add(lbl[i]);
                        }
                        if (green_Red_label == "Green" && lbl[i].BackColor.G != 0 )
                        {
                            result.Add(lbl[i]);
                        }
                    }
                    if (lbl[i].Text != "")
                    {
                        if (green_Red_label == "Red" && lbl[i].Text=="R")
                        {
                            result.Add(lbl[i]);
                        }
                        if (green_Red_label == "Green" && lbl[i].Text == "G")
                        {
                            result.Add(lbl[i]);
                        }
                    }

                }
            }
            return result;

        }

        private void Arrange1(UserControl1 UC, List<Button> tempList)
        {
            UC.Controls.Clear();
            int currPosition = 2;
            for (int i = 0; i < tempList.Count; i++)
            {
                Button tempLabel = tempList[i];
                tempLabel.Location = new Point(currPosition, 2);
                UC.Controls.Add(tempLabel);
                currPosition += tempLabel.Width + 2;
            }
        }

        void Arrange(UserControl1 UC, List<Label> tempList)
        {
            UC.Controls.Clear();
            int currPosition = 2;
            for (int i = 0; i < tempList.Count; i++)
            {
                Label tempLabel = tempList[i];
                tempLabel.Location = new Point(currPosition, 2);
                UC.Controls.Add(tempLabel);
                currPosition += tempLabel.Width + 2;
            }
        }
    }
}

