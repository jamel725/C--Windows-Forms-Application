﻿namespace RecoursiveConstructor_RGB_Text
{
    public class myEventArgs : EventArgs
    {
        public String Buttonlabel;
        public String Textemp;
        public String bysizebybrithes;
        public UserControl1 uc;
        public Control sort;
    }
}
