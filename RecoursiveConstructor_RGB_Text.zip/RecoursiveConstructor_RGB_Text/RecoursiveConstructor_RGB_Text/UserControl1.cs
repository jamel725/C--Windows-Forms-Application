﻿using System.Windows.Forms;

namespace RecoursiveConstructor_RGB_Text
{
    public delegate void delegate_MyEventHadler(object sender, myEventArgs e);
    public partial class UserControl1 : UserControl
    {
        public Control[] arrControls;
        private static Random tempRand = new Random();
        public event delegate_MyEventHadler event_FromUC;
        public UserControl1(Random ucRand)
        {
            InitializeComponent();
            int arrSize = ucRand.Next(18, 35);
            arrControls = new Control[arrSize];

            int currPosition = 2;
            for (int i = 0; i < arrSize; i++)
            {
                if (tempRand.Next(2) == 0)
                {
                    arrControls[i] = new Label();
                    ((Label)arrControls[i]).TextAlign = ContentAlignment.MiddleCenter;
                }
                else
                    arrControls[i] = new Button();

                arrControls[i].Font = new Font("Arial", 14, FontStyle.Bold);
                arrControls[i].Location = new Point(currPosition, 3);
                int temp = tempRand.Next(45, 55);
                switch (tempRand.Next(4))
                {
                    case 0: arrControls[i].Size = new Size(temp, temp); break;
                    case 1: arrControls[i].Size = new Size(temp * 3 / 2, temp * 3 / 2); break;
                    case 2: arrControls[i].Size = new Size(temp * 3 / 2, temp); break;
                    case 3: arrControls[i].Size = new Size(temp, temp * 3 / 2); break;
                }
                switch (tempRand.Next(4))
                {
                    case 0: arrControls[i].BackColor = Color.FromArgb(tempRand.Next(150, 256), 0, 0); break;
                    case 1: arrControls[i].BackColor = Color.FromArgb(0, tempRand.Next(150, 256), 0); break;
                    case 2:
                        arrControls[i].BackColor = Color.White;
                        arrControls[i].ForeColor = Color.FromArgb(tempRand.Next(150, 256), 0, 0);
                        arrControls[i].Text = "R"; break;
                    case 3:
                        arrControls[i].BackColor = Color.White;
                        arrControls[i].ForeColor = Color.FromArgb(0, tempRand.Next(150, 256), 0);
                        arrControls[i].Text = "G"; break;
                }
                currPosition += arrControls[i].Size.Width + 3;
                this.Controls.Add(arrControls[i]);
            }
        }
        private void UserControl1_Click(object sender, EventArgs e)
        {
            myEventArgs tempEventArgs = new myEventArgs();
            tempEventArgs.uc = this;
            if (event_FromUC != null)
                event_FromUC(this, tempEventArgs);

        }
    }
}
