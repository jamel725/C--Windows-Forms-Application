﻿
namespace RecoursiveConstructor_RGB_Text
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Green_Red_label = new Label();
            Rectangle_Square_label = new Label();
            Text_Empty_label = new Label();
            bySize_byBrightness_label = new Label();
            SuspendLayout();
            // 
            // Green_Red_label
            // 
            Green_Red_label.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Bold);
            Green_Red_label.Location = new Point(265, 5);
            Green_Red_label.Margin = new Padding(5, 0, 5, 0);
            Green_Red_label.Name = "Green_Red_label";
            Green_Red_label.Size = new Size(117, 42);
            Green_Red_label.TabIndex = 11;
            Green_Red_label.Text = "Green";
            // 
            // Rectangle_Square_label
            // 
            Rectangle_Square_label.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Bold);
            Rectangle_Square_label.Location = new Point(448, 5);
            Rectangle_Square_label.Margin = new Padding(5, 0, 5, 0);
            Rectangle_Square_label.Name = "Rectangle_Square_label";
            Rectangle_Square_label.Size = new Size(188, 42);
            Rectangle_Square_label.TabIndex = 12;
            Rectangle_Square_label.Text = "Rectangle";
            // 
            // Text_Empty_label
            // 
            Text_Empty_label.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Bold);
            Text_Empty_label.Location = new Point(700, 5);
            Text_Empty_label.Margin = new Padding(5, 0, 5, 0);
            Text_Empty_label.Name = "Text_Empty_label";
            Text_Empty_label.Size = new Size(115, 42);
            Text_Empty_label.TabIndex = 14;
            Text_Empty_label.Text = "Text";
            // 
            // bySize_byBrightness_label
            // 
            bySize_byBrightness_label.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Bold);
            bySize_byBrightness_label.Location = new Point(879, 5);
            bySize_byBrightness_label.Margin = new Padding(5, 0, 5, 0);
            bySize_byBrightness_label.Name = "bySize_byBrightness_label";
            bySize_byBrightness_label.Size = new Size(277, 42);
            bySize_byBrightness_label.TabIndex = 14;
            bySize_byBrightness_label.Text = "bySize";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 255);
            ClientSize = new Size(1880, 310);
            Controls.Add(bySize_byBrightness_label);
            Controls.Add(Rectangle_Square_label);
            Controls.Add(Green_Red_label);
            Controls.Add(Text_Empty_label);
            Margin = new Padding(5, 4, 5, 4);
            Name = "Form1";
            Text = "Button";
            FormClosing += Form1_FormClosing;
            ResumeLayout(false);
        }


        #endregion
        private System.Windows.Forms.Label Green_Red_label;
        private System.Windows.Forms.Label Rectangle_Square_label;
        private System.Windows.Forms.Label bySize_byBrightness_label;
        private System.Windows.Forms.Label Text_Empty_label;

        private System.Windows.Forms.Control Max_control;
    }
}

